=================================================================
Assignment 3
=================================================================

WASD for movement.
NUMPAD 8246 for viewing.
Hold NUMPAD 5 for running.
Press E to Interact with Objects.
Press R to Reset Position.
