#include "Light.h"

Light::Light()
{

}

Light::~Light()
{

}